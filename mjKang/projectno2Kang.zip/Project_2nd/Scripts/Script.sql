use projectno2;

CREATE TABLE calendarlist(
	id varchar(50) PRIMARY KEY,
	checkdate date,
	state int(1),
	content varchar(100)
)
