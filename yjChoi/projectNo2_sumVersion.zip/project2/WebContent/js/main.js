function search() {
	location.href = "http://localhost:8888/project2/searchresult.jsp";
};
function login() {
	location.href = "http://localhost:8888/project2/login.jsp";
};
function logout() {	
	location.href = "http://localhost:8888/project2/logout.jsp";
};
function join(){
	location.href = "http://localhost:8888/project2/join2.jsp";
};
function main() {
	location.href = "http://localhost:8888/project2/main.jsp";
};
function change() {
	location.href = "http://localhost:8888/project2/change.jsp";
};
function regworker() {
	location.href = "http://localhost:8888/project2/worker/regworker.jsp";
};
function checkworker() {
	location.href = "http://localhost:8888/project2/worker/checkworker.jsp";
};
