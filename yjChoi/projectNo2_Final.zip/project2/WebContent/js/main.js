function search() {
	location.href = "http://localhost:8888/project2/searchresult.jsp";
};
function login() {
	location.href = "http://localhost:8888/project2/login.jsp";
};
function logout() {	
	location.href = "http://localhost:8888/project2/logout.jsp";
};
function join(){
	location.href = "http://localhost:8888/project2/join2.jsp";
};
function main() {
	location.href = "http://localhost:8888/project2/main.jsp";
};
function change() {
	location.href = "http://localhost:8888/project2/change.jsp";
};
function regworker() {
	location.href = "http://localhost:8888/project2/worker/regworker.jsp";
};
function checkworker() {
	location.href = "http://localhost:8888/project2/worker/checkworker.jsp";
};
function format4() {
	location.href = "http://localhost:8888/project2/2_1_Format4_Ver5.jsp";
};
function checkuser() {
	location.href = "http://localhost:8888/project2/2_1_Format4_Ver5_check.jsp";
};

