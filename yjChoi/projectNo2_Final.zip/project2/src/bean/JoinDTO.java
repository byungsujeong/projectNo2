package bean;

public class JoinDTO {

	String mid, type1, type2, type3, address1, address2;
	String wcontent, image, startdate, enddate, checkdate, content;
	int wnum, period1, period2, period3, schedulenum;
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getType1() {
		return type1;
	}
	public void setType1(String type1) {
		this.type1 = type1;
	}
	public String getType2() {
		return type2;
	}
	public void setType2(String type2) {
		this.type2 = type2;
	}
	public String getType3() {
		return type3;
	}
	public void setType3(String type3) {
		this.type3 = type3;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getWcontent() {
		return wcontent;
	}
	public void setWcontent(String wcontent) {
		this.wcontent = wcontent;
	}
	
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public int getWnum() {
		return wnum;
	}
	public void setWnum(int wnum) {
		this.wnum = wnum;
	}
	public int getPeriod1() {
		return period1;
	}
	public void setPeriod1(int period1) {
		this.period1 = period1;
	}
	public int getPeriod2() {
		return period2;
	}
	public void setPeriod2(int period2) {
		this.period2 = period2;
	}
	public int getPeriod3() {
		return period3;
	}
	public void setPeriod3(int period3) {
		this.period3 = period3;
	}
	
	
	
	
	
}
