package bean;

public class WorkerDTO {

	int wnum;
	String mid;
	String type1;
	int period1;
	String type2;
	int period2;
	String type3;
	int period3;
	String address1;
	String address2;
	String wcontent;
	
	public int getWnum() {
		return wnum;
	}
	public void setWnum(int wnum) {
		this.wnum = wnum;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getType1() {
		return type1;
	}
	public void setType1(String type1) {
		this.type1 = type1;
	}
	public int getPeriod1() {
		return period1;
	}
	public void setPeriod1(int period1) {
		this.period1 = period1;
	}
	public String getType2() {
		return type2;
	}
	public void setType2(String type2) {
		this.type2 = type2;
	}
	public int getPeriod2() {
		return period2;
	}
	public void setPeriod2(int period2) {
		this.period2 = period2;
	}
	public String getType3() {
		return type3;
	}
	public void setType3(String type3) {
		this.type3 = type3;
	}
	public int getPeriod3() {
		return period3;
	}
	public void setPeriod3(int period3) {
		this.period3 = period3;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getWcontent() {
		return wcontent;
	}
	public void setWcontent(String wcontent) {
		this.wcontent = wcontent;
	}
		
}
