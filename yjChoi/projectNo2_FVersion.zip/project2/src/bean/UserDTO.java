package bean;

public class UserDTO {
	
	String regNum;
	String mid;
	String storename;
	String postcode;
	String roadAddress;
	String detailAddress;
	String type;
	String sSize;
	String sInfo;
	String sImgsrc;
	
	
	public String getRegNum() {
		return regNum;
	}
	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getStorename() {
		return storename;
	}
	public void setStorename(String storename) {
		this.storename = storename;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getRoadAddress() {
		return roadAddress;
	}
	public void setRoadAddress(String roadAddress) {
		this.roadAddress = roadAddress;
	}
	public String getDetailAddress() {
		return detailAddress;
	}
	public void setDetailAddress(String detailAddress) {
		this.detailAddress = detailAddress;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getsSize() {
		return sSize;
	}
	public void setsSize(String sSize) {
		this.sSize = sSize;
	}
	public String getsInfo() {
		return sInfo;
	}
	public void setsInfo(String sInfo) {
		this.sInfo = sInfo;
	}
	public String getsImgsrc() {
		return sImgsrc;
	}
	public void setsImgsrc(String sImgsrc) {
		this.sImgsrc = sImgsrc;
	}
		
}
